#ifndef __BSP_SERVO_H_
#define __BSP_SERVO_H_

#include "ti_msp_dl_config.h"



void Set_Servo270_Angle(unsigned int angle);
void Set_Servo_Angle(unsigned int angle);
unsigned int Get_Servo_Angle(void);
unsigned int Get_Servo_Angle270(void);

#endif

